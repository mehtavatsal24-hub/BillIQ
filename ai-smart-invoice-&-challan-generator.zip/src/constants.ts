import { DocumentType } from "./types";

export const DEFAULT_TERMS = "1. Goods once sold will not be taken back.\n2. Interest @ 18% p.a. will be charged if payment is not made within due date.\n3. Subject to local jurisdiction.";

export const DOCUMENT_TYPE_OPTIONS = Object.values(DocumentType);

export const TAX_RATES = [0, 5, 12, 18, 28];

export const UNITS = [
  "NOS",
  "PCS",
  "KGS",
  "GRAMS",
  "TONS",
  "QUINTAL",
  "LTR",
  "LITERS",
  "ML",
  "GALLONS",
  "MTR",
  "FEET",
  "INCH",
  "SQM",
  "SQF",
  "CBM",
  "CFT",
  "SET",
  "BOX",
  "PKT",
  "BAG",
  "DRM",
  "ROL",
  "CAN",
  "BTL",
  "CTN",
  "DOZ",
  "PAIRS",
  "BUNDLE",
  "HRS",
  "DAY",
  "JOB",
  "SRV",
  "LOT"
];

export function normalizeUnit(unitStr?: string): string {
  if (!unitStr) return "NOS";
  const raw = unitStr.trim();
  const u = raw.toUpperCase();
  
  if (u === "LITER" || u === "LITERS" || u === "LITRE" || u === "LITRES") return "LITERS";
  if (u === "LTR" || u === "LTRS" || u === "L") return "LTR";
  if (u === "ML" || u === "MILLILITER" || u === "MILLILITRES") return "ML";
  if (u === "GAL" || u === "GALLON" || u === "GALLONS") return "GALLONS";
  if (u === "KG" || u === "KGS" || u === "KILOGRAM" || u === "KILOGRAMS" || u.includes("KILOGRAM")) return "KGS";
  if (u === "GM" || u === "GMS" || u === "GRAM" || u === "GRAMS") return "GRAMS";
  if (u === "TON" || u === "TONS" || u === "MT" || u.includes("METRIC TON")) return "TONS";
  if (u === "QTL" || u === "QUINTAL" || u === "QUINTALS") return "QUINTAL";
  if (u === "MTR" || u === "M" || u === "METER" || u === "METERS" || u === "METRES") return "MTR";
  if (u === "FT" || u === "FEET" || u === "FOOT") return "FEET";
  if (u === "IN" || u === "INCH" || u === "INCHES") return "INCH";
  if (u === "PCS" || u === "PC" || u === "PIECE" || u === "PIECES") return "PCS";
  if (u === "SET" || u === "SETS") return "SET";
  if (u === "BOX" || u === "BOXES") return "BOX";
  if (u === "CTN" || u === "CARTON" || u === "CARTONS") return "CTN";
  if (u === "PKT" || u === "PKTS" || u === "PACKET" || u === "PACKETS" || u === "PACK" || u === "PACKS") return "PKT";
  if (u === "BAG" || u === "BAGS") return "BAG";
  if (u === "DRM" || u === "DRUM" || u === "DRUMS" || u.includes("DRUM")) return "DRM";
  if (u === "CAN" || u === "CANS" || u === "JERRYCAN" || u === "JERRYCANS") return "CAN";
  if (u === "BTL" || u === "BOTTLE" || u === "BOTTLES") return "BTL";
  if (u === "DOZ" || u === "DZ" || u === "DOZEN" || u === "DOZENS") return "DOZ";
  if (u === "PAIR" || u === "PAIRS" || u === "PRS") return "PAIRS";
  if (u === "BDL" || u === "BUNDLE" || u === "BUNDLES") return "BUNDLE";
  if (u === "ROL" || u === "ROLL" || u === "ROLLS") return "ROL";
  if (u === "SQM" || u === "SQ.M" || u === "SQ MTR" || u === "SQMTR") return "SQM";
  if (u === "SQF" || u === "SQ.FT" || u === "SQFT" || u === "SQ FEET") return "SQF";
  if (u === "CBM" || u === "CU.M" || u === "CUBIC METER" || u === "CUBIC METERS") return "CBM";
  if (u === "CFT" || u === "CU.FT" || u === "CUBIC FEET") return "CFT";
  if (u === "HR" || u === "HRS" || u === "HOUR" || u === "HOURS") return "HRS";
  if (u === "DAY" || u === "DAYS") return "DAY";
  if (u === "JOB" || u === "JOBS") return "JOB";
  if (u === "SRV" || u === "SERVICE" || u === "SERVICES") return "SRV";
  if (u === "LOT" || u === "LOTS") return "LOT";
  if (u === "NOS" || u === "NO" || u === "NUMBER" || u === "NUMBERS" || u === "UNIT" || u === "UNITS" || u === "EA" || u === "EACH") return "NOS";
  return u;
}

export const CURRENCY_SYMBOLS: Record<string, string> = {
  "INR": "₹",
  "USD": "$",
  "EUR": "€",
  "GBP": "£",
  "AED": "د.إ",
  "SAR": "﷼",
  "JPY": "¥",
  "SGD": "S$",
  "AUD": "A$",
  "CAD": "C$",
  "CNY": "¥"
};

export const STATES = [
  "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal", "Andaman and Nicobar Islands", "Chandigarh", "Dadra and Nagar Haveli and Daman and Diu", "Delhi", "Jammu and Kashmir", "Ladakh", "Lakshadweep", "Puducherry"
];

export const OWNER_EMAIL = "support@billiq.site";
