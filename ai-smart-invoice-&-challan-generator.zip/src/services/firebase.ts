import { initializeApp, getApp, getApps, FirebaseApp } from "firebase/app";
import { getFirestore, initializeFirestore, memoryLocalCache, setLogLevel, Firestore } from "firebase/firestore";
import { getAuth, Auth } from "firebase/auth";
import { getAnalytics, isSupported, Analytics } from "firebase/analytics";

// Import the Firebase configuration
import rawFirebaseConfig from "../../firebase-applet-config.json";

// Set custom auth domain and Firebase config with fallback defaults
const firebaseConfig = {
  ...rawFirebaseConfig,
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || (rawFirebaseConfig as any)?.apiKey || "AIzaSyCuFBQe3Wr0qO4ybrJBGuu7Bcsy-DfMtew",
  authDomain: (rawFirebaseConfig as any)?.authDomain || "new-app-74245.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || (rawFirebaseConfig as any)?.projectId || "new-app-74245",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || (rawFirebaseConfig as any)?.storageBucket || "new-app-74245.firebasestorage.app",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || (rawFirebaseConfig as any)?.messagingSenderId || "70732456690",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || (rawFirebaseConfig as any)?.appId || "1:70732456690:web:cdf42bf5e1344c9af1666b",
  measurementId: (rawFirebaseConfig as any)?.measurementId || "G-3K3F4T7DQB",
};

// Silence internal Firestore SDK assertion logs
try {
  setLogLevel("silent");
} catch {
  // Ignore
}

let app: FirebaseApp | null = null;
let db: Firestore | null = null;
let auth: Auth | null = null;
let analytics: Analytics | null = null;

try {
  const existingApps = getApps();
  if (existingApps.length > 0) {
    app = getApp();
  } else if (firebaseConfig.apiKey && firebaseConfig.projectId) {
    app = initializeApp(firebaseConfig);
  }
} catch (error) {
  try {
    app = getApp();
  } catch (initErr) {
    console.warn("Firebase app initialization notice:", initErr);
  }
}

if (app) {
  // Initialize Firestore safely with database ID support
  const dbId = (rawFirebaseConfig as any)?.firestoreDatabaseId || "(default)";
  try {
    db = getFirestore(app, dbId);
  } catch {
    try {
      db = initializeFirestore(app, {
        experimentalForceLongPolling: true,
        localCache: memoryLocalCache()
      }, dbId);
    } catch {
      try {
        db = getFirestore(app, dbId);
      } catch (fErr) {
        console.warn("Firestore initialization fallback:", fErr);
      }
    }
  }

  // Initialize Auth safely
  try {
    auth = getAuth(app);
  } catch (authErr) {
    console.warn("Auth initialization notice:", authErr);
  }

  // Initialize Analytics safely in browser
  if (typeof window !== "undefined") {
    isSupported().then((supported) => {
      if (supported && app) {
        try {
          analytics = getAnalytics(app);
        } catch (e) {
          // Ignore analytics initialization warnings in iframe/sandboxed environments
        }
      }
    }).catch(() => {});
  }
}

// Check if we have the minimum required config and active app
const isConfigValid = !!(app && firebaseConfig.apiKey && firebaseConfig.projectId);

export { app, db, auth, analytics, isConfigValid };

